#include "game.h"

int main()
{
	Game game("ALIEN XII",
		1920, 1080,
		4, 4,
		false);

	//MAIN LOOP
	while (!game.getWindowShouldClose())
	{
		//Update input
		game.update();

		//Render game
		game.render();
	}

	return 0;
}